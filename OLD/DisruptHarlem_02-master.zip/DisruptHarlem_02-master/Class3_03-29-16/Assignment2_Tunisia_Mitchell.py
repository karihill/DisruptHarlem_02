Hello Class,

An example of how to upload an assignment.

Happy Coding,
Tunisia Mitchell