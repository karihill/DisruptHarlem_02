# Welcome to Disrupt Harlem Coding Squad!!

We will be using this repository to pull, push, and share code/materials relevant to this program.

Looking forward to programming with all of you.

Happy Coding, 
<p>Tunisia Mitchell</p>
